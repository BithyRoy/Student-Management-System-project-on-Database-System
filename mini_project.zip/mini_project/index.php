<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Welcome to Student Management System</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </head>

  <body>
      <div class="container"><br>
          <a class="btn btn-primary pull-right" href="admin/login.php">Login</a><br><br>
          <h1 class="text-center">Welcome to Student Management System</h1> <br>

         

          <div class="row">
              <div class="col-sm-4 col-sm-offset-4">
              <form action="" method="POST">
              <table class="table table-bordered">
                  <tr>
                      <td class="text-center" colspan="2"> <label>Student Information</label></td>
                  </tr>

                  <tr>
                      <td> <label for="roll">Student ID </label></td>
                      <td> <input class="form-control" type="text" name="roll" pattern="[0-9]{9}" placeholder="ID"></td>
                  </tr>
              
                  <tr>
                      <td> <label for="department">Select Dept </label></td>
                      <td>
                          <select class="form-control" name="department" id="department">
                              <option value="">Select</option>
                              <option value="CSE">CSE</option>
                              <option value="EEE">EEE</option>
                              <option value="TE">TE</option>
                              <option value="BBA">BBA</option>
                              <option value="LLB">LLB</option>
                          </select>
                      </td>
                  </tr>
              
                  <tr>
                      <td class="text-center" colspan="2"> <input class="btn btn-default" type="submit" value="Show Info" name="show_info"></td>
                  </tr>
              </table>

              </div>
          </div>
          </form>

          <br><br>

          <?php 
          require_once './admin/dbcon.php';
          if(isset($_POST['show_info'])){
              
              $dept = $_POST['department'];
              $roll = $_POST['roll'];

              $result =  mysqli_query($link, "SELECT * FROM `student_info` WHERE `department`='$dept' and `roll`='$roll'");

              if(mysqli_num_rows($result) == 1){
                  $row = mysqli_fetch_assoc($result);

                ?>


<div class="row">
          <div class="col-sm-6 col-sm-offset-3">
              <table class="table table-bordered">
                  <tr>
                      <td rowspan="5"> 
                          <img style=" width:100px;" class="img-thumbnail" src="admin/student_images/<?= $row['photo']; ?>" alt="">
                      </td>
                      <td>Name</td>
                      <td><?= ucwords($row['name']); ?></td>
                  </tr>

                  <tr>
                      
                      <td>ID</td>
                      <td><?= $row['roll']; ?></td>
                  </tr>

                  <tr>
                     
                      <td>Departmenet</td>
                      <td><?= $row['department']; ?></td>
                  </tr>

                  <tr>
                    
                      <td>City</td>
                      <td><?= ucwords($row['city']); ?></td>
                  </tr>

                  <tr>
                      
                      <td>Contact</td>
                      <td><?= $row['contact']; ?></td>
                  </tr>
              </table>
          </div>
          </div>

          <footer> 
    <p style="text-align: center; margin-top:20px;" >Copyright &copy; 2016 - <?= date('Y')  ?> | Students Management system. All Right Resereved</p>
    </footer>

        <?php
            } else {

            ?>
            <script type="text/javascript">
            alert('Data Not Found');
        </script>
            

        <?php }}?>
              
       
      </div>
  </body>
</html>