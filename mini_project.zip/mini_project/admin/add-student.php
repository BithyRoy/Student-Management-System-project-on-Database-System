
<h1 class="text-primary"> <i class="fa fa-user-plus"></i>Add Student<small> Add New Student</small> </h1>
        <ol class="breadcrumb">
          <li> <a href="index.php?page=dashboard"> <i class="fa fa-dashboard"></i> Dashboard</a></li>
          <li class="active"><i class="fa fa-user-plus"></i> Add Student</li>
        </ol>

<?php

if(isset($_POST['add-student'])){

    $name = $_POST['name'];
    $roll = $_POST['roll'];
    $dept = $_POST['department'];
    $city = $_POST['city'];
    $contact = $_POST['contact'];

    $photo = explode('.', $_FILES['photo']['name']);
    $photo = end($photo);
    $photo_name = $roll.'.'.$photo;


    $query = "INSERT INTO `student_info`( `name`, `roll`, `department`, `city`, `contact`, `photo`) VALUES ('$name','$roll','$dept','$city','$contact', '$photo_name')";
    
    $result = mysqli_query($link, $query);

    if($result){
        $success = "Data Insert Success!";
        move_uploaded_file($_FILES['photo']['tmp_name'], 'student_images/'.$photo_name);
    } else {
        $eror = "Wrong";
    }
   
}

?>




<div class="row">
<?php if(isset($success)){echo '<p class="alert alert-success col-sm-6">'.$success.'</p>';} ?>
    
<?php if(isset($eror)){echo '<p class="alert alert-danger col-sm-6">'.$eror.'</p>';} ?>

</div>


<div class="row">
<div class="col-sm-6">
<form action="" method="POST" enctype="multipart/form-data">

<div class="form-group">
<label for="name">Student Name</label>
<input type="text" name="name" placeholder="Student Name" id="name" class="form-control" required>
</div>

<div class="form-group">
<label for="roll">Student ID</label>
<input type="text" name="roll" placeholder="Student ID" id="roll" class="form-control" pattern="[0-9]{9}" required>
</div>

<div class="form-group">
<label for="department">Department </label>
<select class="form-control" name="department" id="department" required>
                              <option value="">Select</option>
                              <option value="CSE">CSE</option>
                              <option value="EEE">EEE</option>
                              <option value="TE">TE</option>
                              <option value="BBA">BBA</option>
                              <option value="LLB">LLB</option>
                          </select>
</div>

<div class="form-group">
<label for="city">City</label>
<input type="text" name="city" placeholder="city" id="city" class="form-control" required>
</div>

<div class="form-group">
<label for="contact">Contact</label>
<input type="text" name="contact" placeholder="01***" id="contact" class="form-control" pattern="01[1|5|6|7|8|9][0-9]{}" required>
</div>

<div class="form-group">
    <label for="photo">Photo</label>
    <input id="photo" type="file" name="photo" required>

</div>

<div class="form-group">
    <input type="submit" value="Add Student" name="add-student" class="btn btn-primary pull-right">
</div>

</form>
</div>
</div>