<h1 class="text-primary"> <i class="fa fa-pencil-square"></i> Update Profile<small> Update Your Profile</small> </h1>
        <ol class="breadcrumb">
          <li> <a href="index.php?page=dashboard"> <i class="fa fa-dashboard"></i> Dashboard</a></li>
          <li class="active"><i class="fa fa-pencil-square"></i> Update Profile</li>
        </ol>

        <?php
        $session_user = $_SESSION['user_login'];

        $user_data = mysqli_query($link, "SELECT * FROM `users` WHERE `username` ='$session_user'");

        $user_row = mysqli_fetch_assoc($user_data);


        ?>


<?php 
        require_once  './dbcon.php';
        $id = base64_decode($_GET['id']);
        $db_data = mysqli_query($link, "SELECT * FROM `users` WHERE `id` = '$id'");

        $db_row = mysqli_fetch_assoc($db_data);
        
        if(isset($_POST['edit-profile'])){

            $id = $_POST['id'];
            $name = $_POST['name'];
            $username = $_POST['username'];
            $email = $_POST['email'];
    
            $query = "UPDATE `users` SET `id`='$id',`name`='$mane',`username`='$username',`email`='$email' WHERE `id`='$id'";
                $result = mysqli_query($link, $query);
    
                if($result){
                    header('location: index.php?page=user-profile');
                }
    
       
             }
        ?>


        <div class="row">
        <div class="col-sm-6">
        <table class="table table-bordered">
                <tr>
                    <td>User ID</td>
                    <td><input type="text" name="id" placeholder="ID" id="id" class="form-control" value="<?= $db_row['id'] ?>"></td>
                </tr>
                </tr>

                <tr>
                    <td>Name</td>
                    <td><input type="text" name="name" placeholder="Name" id="name" class="form-control" value="<?= ucwords($db_row['name']); ?>"></td>
                </tr>
                </tr>

                <tr>
                    <td>Username</td>
                    <td><input type="text" name="username" placeholder="Username" id="username" class="form-control" value="<?= $db_row['username'] ?>"></td>
                </tr>
                </tr>

                <tr>
                    <td>Email</td>
                    <td><input type="text" name="email" placeholder="Email" id="email" class="form-control" value="<?= $db_row['email'] ?>"></td>
                </tr>
                </tr>

                <tr>
                    <td>Status</td>
                    <td><input type="text" name="status" placeholder="Status" id="status" class="form-control" value="<?=ucwords( $db_row['status']); ?>" disabled></td>
                </tr>
                </tr>

                <tr>
                    <td>Signup Date</td>
                    <td><input type="text" name="datetime" placeholder="Signup Date" id="datetime" class="form-control" value="<?= $db_row['datetime']; ?>" disabled></td>
                </tr>
                </tr>
            </table>
            <input type="submit" name="edit-profile" value="Update Profile" class="btn btn-sm btn-info pull-right">
        </div>
         

        <div class="col-sm-6">
           <a href="">
           <td> <img style=" width:100px;" class="img-thumbnail" src="images/<?= $user_row['photo']; ?>" alt=""></td>
           </a>  <br> <br>
           <?php

           if(isset($_POST['upload'])){
            $photo = explode('.', $_FILES['photo']['name']);
            $photo = end($photo);
            $photo_name = $session_user.'.'.$photo;

            $upload = mysqli_query($link, "UPDATE `users` SET `photo`='$photo_name' WHERE `username`='$session_user'");

            if($upload){

                move_uploaded_file($_FILES['photo']['tmp_name'], 'images/'.$photo_name);
                
            }


           }

           ?>

           <form action="" enctype="multipart/form-data" method="POST" >
               <label for="photo">Profile Picture</label>
               <input type="file" name="photo" id="photo" required><br>
               <input type="submit" name="upload" value="Upload" class="btn btn-sm btn-info">

           </form>


        </div>



        </div>





        