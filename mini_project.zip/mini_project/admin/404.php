<div class="text-center text-danger">
<img style="width:80%;" src="images/404-error-page-not-found.jpg" alt="">
</div>