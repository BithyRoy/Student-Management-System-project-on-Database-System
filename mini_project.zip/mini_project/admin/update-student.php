
<h1 class="text-primary"> <i class="fa fa-pencil-square"></i> Update Student<small> Update Student</small> </h1>
        <ol class="breadcrumb">
          <li> <a href="index.php?page=dashboard"> <i class="fa fa-dashboard"></i> Dashboard</a></li>
          <li> <a href="index.php?page=all-students"> <i class="fa fa-users"></i> All Students</a></li>
          <li class="active"> <i class="fa fa-pencil-square"></i> Update Student</li>
        </ol>

        <?php 
        require_once  './dbcon.php';
        $id = base64_decode($_GET['id']);
        $db_data = mysqli_query($link, "SELECT * FROM `student_info` WHERE `id` = '$id'");

        $db_row = mysqli_fetch_assoc($db_data);

        if(isset($_POST['update-student'])){

        $name = $_POST['name'];
        $roll = $_POST['roll'];
        $dept = $_POST['department'];
        $city = $_POST['city'];
        $contact = $_POST['contact'];

        $query = "UPDATE `student_info` SET `name`='$name',`roll`='$roll',`department`='$dept',`city`='$city',`contact`='$contact' WHERE `id`='$id'";
            $result = mysqli_query($link, $query);

            if($result){
                header('location: index.php?page=all-students');
            }

   
         }
        ?>



<div class="row">
<div class="col-sm-6">
<form action="" method="POST" enctype="multipart/form-data">

<div class="form-group">
<label for="name">Student Name</label>
<input type="text" name="name" placeholder="Student Name" id="name" class="form-control" required value="<?= $db_row['name'] ?>">
</div>

<div class="form-group">
<label for="roll">Student ID</label>
<input type="text" name="roll" placeholder="Student ID" id="roll" class="form-control" pattern="[0-9]{9}" required value="<?= $db_row['roll'] ?>">
</div>

<div class="form-group">
<label for="department">Department </label>
<select class="form-control" name="department" id="department" required>
                              <option value="" disabled>Select</option>
                              <option <?php echo $db_row['department']=='CSE'?'selected=""':'';?> value="CSE">CSE</option>
                              <option <?php echo $db_row['department']=='EEE'?'selected=""':'';?>  value="EEE">EEE</option>
                              <option <?php echo $db_row['department']=='TE'?'selected=""':'';?>  value="TE">TE</option>
                              <option <?php echo $db_row['department']=='BBA'?'selected=""':'';?>  value="BBA">BBA</option>
                              <option <?php echo $db_row['department']=='LLB'?'selected=""':'';?>  value="LLB">LLB</option>
                          </select>
</div>

<div class="form-group">
<label for="city">City</label>
<input type="text" name="city" placeholder="city" id="city" class="form-control" required value="<?= $db_row['city'] ?>">
</div>

<div class="form-group">
<label for="contact">Contact</label>
<input type="text" name="contact" placeholder="01***" id="contact" class="form-control" pattern="01[1|5|6|7|8|9][0-9]{}" required value="<?= $db_row['contact'] ?>">
</div>



<div class="form-group">
    <input type="submit" value="Update Student" name="update-student" class="btn btn-primary pull-right">
</div>

</form>
</div>
</div>